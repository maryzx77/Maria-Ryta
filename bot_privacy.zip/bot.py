from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

TOKEN = "SEU_TOKEN_AQUI"
LINK_PRIVACY = "https://go.pepperpay.com.br/hcpaw?affh=undefined"
IMAGEM_PATH = "foto.jpg"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👋 Olá! Bem-vinde ao meu conteúdo +18 exclusivo!\n"
        f"Acesse o conteúdo completo no meu Privacy:\n{LINK_PRIVACY}"
    )

async def foto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    with open(IMAGEM_PATH, "rb") as image:
        await update.message.reply_photo(
            photo=image,
            caption=f"💋 Gostou? Veja mais no meu Privacy:\n{LINK_PRIVACY}"
        )

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("foto", foto))

app.run_polling()
